<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "krushi saarthi";

$conn = mysqli_connect($host,$user,$pass,$db);
if($conn)
{
	
}
else
{
	echo "Not Connected";
}


?>